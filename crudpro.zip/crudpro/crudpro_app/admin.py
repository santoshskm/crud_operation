from django.contrib import admin
from crudpro_app.models import Student

# Register your models here.
admin.site.register(Student)

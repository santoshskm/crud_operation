from django.apps import AppConfig


class CrudproAppConfig(AppConfig):
    name = 'crudpro_app'
